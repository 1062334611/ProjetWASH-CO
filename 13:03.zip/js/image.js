




function bigit1(){
    var image=document.getElementsByClassName("center")[0];
    image.style.height=image.height*1.1+'px';
    image.style.width=image.width*1.1+'px';
}
function littleit1(){
    var image=document.getElementsByClassName("center")[0];
    image.style.height=image.height/1.1+'px';
    image.style.width=image.width/1.1+'px';
}



function bigit2(){
    var image=document.getElementsByClassName("center")[1];
    image.style.height=image.height*1.1+'px';
    image.style.width=image.width*1.1+'px';
}
function littleit2(){
    var image=document.getElementsByClassName("center")[1];
    image.style.height=image.height/1.1+'px';
    image.style.width=image.width/1.1+'px';
}


function bigit2(){
    var image=document.getElementsByClassName("center")[1];
    image.style.height=image.height*1.1+'px';
    image.style.width=image.width*1.1+'px';
}
function littleit2(){
    var image=document.getElementsByClassName("center")[1];
    image.style.height=image.height/1.1+'px';
    image.style.width=image.width/1.1+'px';
}


function bigit3(){
    var image=document.getElementsByClassName("center")[2];
    image.style.height=image.height*1.1+'px';
    image.style.width=image.width*1.1+'px';
}
function littleit3(){
    var image=document.getElementsByClassName("center")[2];
    image.style.height=image.height/1.1+'px';
    image.style.width=image.width/1.1+'px';
}



function bigit4(){
    var image=document.getElementsByClassName("center")[3];
    image.style.height=image.height*1.1+'px';
    image.style.width=image.width*1.1+'px';
}
function littleit4(){
    var image=document.getElementsByClassName("center")[3];
    image.style.height=image.height/1.1+'px';
    image.style.width=image.width/1.1+'px';
}



function bigit5(){
    var image=document.getElementsByClassName("center")[4];
    image.style.height=image.height*1.1+'px';
    image.style.width=image.width*1.1+'px';
}
function littleit5(){
    var image=document.getElementsByClassName("center")[4];
    image.style.height=image.height/1.1+'px';
    image.style.width=image.width/1.1+'px';
}



