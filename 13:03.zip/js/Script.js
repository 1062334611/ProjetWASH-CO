// JavaScript source code

var barre = document.getElementsByTagName("aside");

function zoom(image){
    var pas=50; 
	image.width+=pas; 
	image.height+=pas; 
	}

function getRandomArbitrary(min, max) {
  return Math.floor(Math.random() * (max - min) + min);
}


	function cacherStock(){
    var stock= document.getElementsByClassName("stockv");
    for(var i=0; i< stock.length; i++){
      stock[i].textContent = ""
    }
	}
	
function afficherStock(){
  
   var stock= document.getElementsByClassName("stockv"); 
 
          

   for(var i=0; i< stock.length; i++){
     stock[i].textContent = getRandomArbitrary(10,100);
     stock[i].style.color="red";
   }	
 
  	}

  afficher=false
  document.getElementById('valid').addEventListener("click", function(e){
    if(!afficher){
      afficherStock()
      e.target.textContent = "Cacher stock"
      
    } 
    else{
      cacherStock()
      e.target.textContent = "stock"
    } 
    afficher=!afficher
  })

	
	
	
document.getElementById("produits").addEventListener("click",function (e){
	e.preventDefault();
/*	afficherStock();
	cacherStock();*/
	zoom(this); 
});

var userAccount = document.querySelector("#userAccount"),//获取用户名

    userName = document.querySelector("#userName"),//获取姓名

    email = document.querySelector("#email"),//获取邮箱号码
    telephone = document.querySelector("#telephone"),//获取手机号码
    items = document.querySelectorAll(".item_"),//获取所有提示文段的下标
    aCho = document.querySelector("#choose"), oBtn = document.querySelector("#handup");
var test1 = false, test2 = false, test3 = false, test4 = false;
userAccount.onfocus = function () {
    items[0].innerHTML = "2-30 lettres";
    items[0].style.color = "green";
};
userAccount.onblur = function () {
    var reg = /^\w{2,30}$/;
    if (this.value == "") {
        items[0].innerHTML = "Veuillez saisir votre nom !";
        items[0].style.color = "red";
        userAccount.style.border="1px solid red";
    } else {
        if (!reg.exec(userAccount.value)) {
            items[0].innerHTML = "2-30 lettres";
            items[0].style.color = "red";
            userAccount.style.border="1px solid red";
        } else {
            items[0].innerHTML = "Le format est correct";
            items[0].style.color = "green";
            test1 = true;
        }
    }
};
//-------------------------------------------------------------nom termine;

userName.onfocus = function () {
    items[1].innerHTML = "Veuillez saisir votre prénom !";
    items[1].style.color = "green";
};
userName.onblur = function () {
    var reg = /^\w{2,30}$/;
    if (this.value == "") {
        items[1].innerHTML = "Veuillez saisir votre prénom !";
        items[1].style.color = "red";
    } else {
        if (!reg.exec(userName.value)) {
            items[1].innerHTML = "Veuillez saisir votre prénom et Confirmez qu'il est dans le bon format! ";
            items[1].style.color = "red";
        } else {
            items[1].innerHTML = "Le format est correct";
            items[1].style.color = "green";
            test2 = true
        }
    }
};
//---------------------------------------------------------------------------------prénom termine

email.onfocus = function () {
    items[2].innerHTML = "Veuillez saisir le format correct de votre e-mail";
    items[2].style.color = "green";
};
email.onblur = function () {
    var reg = /^\w+@\w+.[a-zA-Z]{2,3}(.[a-zA-Z]{2,3})?$/;
    if (this.value == "") {
        items[2].innerHTML = "Veuillez saisir votre adresse e-mail!";
        items[2].style.color = "red";
        userName.style.border="1px solid red";
    } else {
        if (!reg.exec(email.value)) {
            items[2].innerHTML = "Veuillez saisir le format d'e-mail correct";
            items[2].style.color = "red";
            userName.style.border="1px solid red";
        } else {
            items[2].innerHTML = "Le format est correct";
            items[2].style.color = "green";
            test3 = true;
        }
    }
};
//----------------------------------------------------------------------e-mail termine
telephone.onfocus = function () {
    items[3].innerHTML = "Veuillez entrer votre numéro de téléphone";
    items[3].style.color = "green";
};
telephone.onblur = function () {
    var reg = /^\d{10}$/;
    if (this.value == "") {
        items[3].innerHTML = "Veuillez entrer votre numéro de téléphone mobile à 10 chiffres!";
        items[3].style.color = "red";
    } else {
        if (!reg.exec(telephone.value)) {
            items[3].innerHTML = "Veuillez entrer votre numéro de téléphone mobile à 10 chiffres!";
            items[3].style.color = "red";
        } else {
            items[3].innerHTML = "Le format est correct";
            items[3].style.color = "green";
            test4 = true;
        }
    }
};
oBtn.onclick = function () {
    if (aCho.checked == false || test1 == false || test2 == false || test3 == false || test4 == false ) {
        alert(" Le format des informations que vous avez renseignées est incorrect ! ")
    } else {
        alert(" Votre message a bien été envoyé ! ")
    }
};


//--------------------------------------------------------------------------------------------





function bigit1(){
    var image=document.getElementsByClassName("center")[0];
    image.style.height=image.height*1.1+'px';
    image.style.width=image.width*1.1+'px';
}
function littleit1(){
    var image=document.getElementsByClassName("center")[0];
    image.style.height=image.height/1.1+'px';
    image.style.width=image.width/1.1+'px';
}



function bigit2(){
    var image=document.getElementsByClassName("center")[1];
    image.style.height=image.height*1.1+'px';
    image.style.width=image.width*1.1+'px';
}
function littleit2(){
    var image=document.getElementsByClassName("center")[1];
    image.style.height=image.height/1.1+'px';
    image.style.width=image.width/1.1+'px';
}


function bigit2(){
    var image=document.getElementsByClassName("center")[1];
    image.style.height=image.height*1.1+'px';
    image.style.width=image.width*1.1+'px';
}
function littleit2(){
    var image=document.getElementsByClassName("center")[1];
    image.style.height=image.height/1.1+'px';
    image.style.width=image.width/1.1+'px';
}


function bigit3(){
    var image=document.getElementsByClassName("center")[2];
    image.style.height=image.height*1.1+'px';
    image.style.width=image.width*1.1+'px';
}
function littleit3(){
    var image=document.getElementsByClassName("center")[2];
    image.style.height=image.height/1.1+'px';
    image.style.width=image.width/1.1+'px';
}



function bigit4(){
    var image=document.getElementsByClassName("center")[3];
    image.style.height=image.height*1.1+'px';
    image.style.width=image.width*1.1+'px';
}
function littleit4(){
    var image=document.getElementsByClassName("center")[3];
    image.style.height=image.height/1.1+'px';
    image.style.width=image.width/1.1+'px';
}



function bigit5(){
    var image=document.getElementsByClassName("center")[4];
    image.style.height=image.height*1.1+'px';
    image.style.width=image.width*1.1+'px';
}
function littleit5(){
    var image=document.getElementsByClassName("center")[4];
    image.style.height=image.height/1.1+'px';
    image.style.width=image.width/1.1+'px';
}




